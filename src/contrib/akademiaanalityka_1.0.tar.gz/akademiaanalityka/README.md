# Akademia Analityka

Zbiory danych do warsztatu na Akademii Analityka.
