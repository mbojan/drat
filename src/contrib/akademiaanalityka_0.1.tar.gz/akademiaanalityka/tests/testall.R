library(testthat)
library(akademiaanalityka)

test_package("akademiaanalityka")
