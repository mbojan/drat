context("Testowanie kodowania na UTF-8")

test_that("koduj zwraca poprawnie tekst bez polskich znakow",
          {
            x <- "gadery poluki"
            expect_identical(x, koduj(x))
          }
)
