library(testthat)
library(alluvial)

test_package("alluvial")
