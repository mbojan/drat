
# travispkg

<!-- badges: start -->
[![Travis build status](https://travis-ci.org/mbojan/travispkg.svg?branch=master)](https://travis-ci.org/mbojan/travispkg)
<!-- badges: end -->

This is a proof-of-concept dummy R package that aims to use TravisCI to:

- Run `R CMD check` on Linux, MacOS, and **Windows**.
- Push package tarball, MacOS binary, and Windows binary to a [drat](https://github.com/eddelbuettel/drat) repository, as proposed [here](https://cran.r-project.org/web/packages/drat/vignettes/CombiningDratAndTravis.html)
