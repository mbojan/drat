context("Testing fun()")


test_that("fun () works", {
            expect_identical(1, fun(1))
})
