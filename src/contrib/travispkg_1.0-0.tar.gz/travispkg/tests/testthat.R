library(testthat)
library(travispkg)

test_check("travispkg")
