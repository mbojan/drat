#' A dummy R function
#'
#' @param x an argument
#'
#' @return Argument is returned as is.
#'
#' @export

fun <- function(x) x
