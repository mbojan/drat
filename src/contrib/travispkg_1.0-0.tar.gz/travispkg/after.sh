env
ls
