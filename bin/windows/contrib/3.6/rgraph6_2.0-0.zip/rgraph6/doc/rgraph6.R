params <-
list(figpath = "rgraph6-")

## ----setup, include=FALSE, cache=FALSE----------------------------------------
knitr::opts_chunk$set(
  cache=FALSE,
  collapse=TRUE,
  fig.path = params$figpath
  )

## ----badges, echo=FALSE, results="asis", eval=knitr::opts_knit$get("rmarkdown.pandoc.to") == "markdown_github"----
#  cat("
#  [![Build Status](https://travis-ci.org/mbojan/rgraph6.png?branch=master)](https://travis-ci.org/mbojan/rgraph6)
#  [![Build Status](https://ci.appveyor.com/api/projects/status/4jl7qg3etk9g8eo0?svg=true)](https://ci.appveyor.com/project/mbojan/rgraph6)
#  [![rstudio mirror downloads](http://cranlogs.r-pkg.org/badges/rgraph6?color=2ED968)](http://cranlogs.r-pkg.org/)
#  [![cran version](http://www.r-pkg.org/badges/version/rgraph6)](https://cran.r-project.org/package=rgraph6)
#      ")

## ----installation, eval=FALSE-------------------------------------------------
#  devtools::install_github("mbojan/rgraph6", build_vignettes=TRUE)

